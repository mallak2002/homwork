﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_Assignment
{
   public class Person
    {
        private string firsName;
        private string lastname;
        public Person()
        {
            this.firsName = "Malak Saqer";
            this.lastname = "Al-ajlouni";
        }
        public string FirsName { get => firsName; set => firsName = value; }
        public string LastName { get => lastname; set => lastname = value; }
    }
}
