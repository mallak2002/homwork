﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ATM_Assignment
{
    public class Bank
    {
        private int bankCapacity;
        private BankAccount[] all_acount;
        public Bank(int bankCapacity)
        {
            this.BankCapacity = bankCapacity;
            this.  numberOfCustomers = 0;
            this.all_acount = new BankAccount[bankCapacity];

        }

        public Bank()

        {
            this.numberOfCustomers = 0;
        }

        public int BankCapacity { get => bankCapacity; set => bankCapacity = value; }
        public int NumberOfCustomers { get => numberOfCustomers; set => numberOfCustomers = value; }

        private int numberOfCustomers;

        public void AddNewAccount(BankAccount a)
        {
            all_acount[numberOfCustomers++] = a;


        }

        public bool IsBankUser(string cardNumber, string pinCode)
        {
            for(int a = 0; a < numberOfCustomers; a++)
            {
                if (all_acount[a].CardNumber.Equals(cardNumber) && all_acount[a].PinCode.Equals(pinCode))
                    return true;
            }

            return false;
        }

        public int CheckBalance(string cardNumber, string pinCode)
        {
            for (int a = 0; a < numberOfCustomers; a++)
            {
                if (all_acount[a].CardNumber.Equals(cardNumber) && all_acount[a].PinCode.Equals(pinCode))
                    return all_acount[a].AccountBalance;
            }

            return 0;
        }

        public void Withdraw(BankAccount t, int withdrawAmount)
        {
            for (int a = 0; a < numberOfCustomers; a++)
            {
                if (all_acount[a].CardNumber.Equals(t.CardNumber) && all_acount[a].PinCode.Equals(t.PinCode) && all_acount[a].AccountBalance>= withdrawAmount)
                    all_acount[a].AccountBalance-= withdrawAmount;
            }
        }

        public void Deposit(BankAccount t, int DepositawAmount)
        {
            if (DepositawAmount > 0)
            {
                for (int a = 0; a < numberOfCustomers; a++)
                {
                    if (all_acount[a].CardNumber.Equals(t.CardNumber) && all_acount[a].PinCode.Equals(t.PinCode))
                        all_acount[a].AccountBalance += DepositawAmount;
                }
            }
        }

        public void Save()
        {
            string s = "";
            for (int a = 0; a < numberOfCustomers; a++)
            {
                s += all_acount[a].P1.FirsName + "," + all_acount[a].P1.LastName + "," + all_acount[a].CardNumber + "," + all_acount[a].PinCode + "," + all_acount[a].Email + "," + all_acount[a].AccountBalance + "\n";
            }
            string c = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "data.txt");
            using (StreamWriter writer = new StreamWriter(c))
            {
                writer.Write(s);
            }
        }

        public void Load()
        {
            string c = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "data.txt");
            using (StreamReader reder = new StreamReader(c))
            {
                string s ="";
               

                while ((s = reder.ReadLine()) != null)
                {
                    string[] line = s.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    Console.WriteLine(line.Length);
                    if (line.Length == 5)
                    {
                        Person P1 = new Person();
                        P1.FirsName = line[0];
                        P1.LastName = line[1];
                        BankAccount b = new BankAccount(P1, line[4], line[2], line[3], int.Parse(line[5]));
                        all_acount[numberOfCustomers++] = b;
                    }

                }
            }
            }
    }
}
