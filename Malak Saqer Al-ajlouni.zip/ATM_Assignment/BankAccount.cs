﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_Assignment
{
    public class BankAccount
    {
        private Person p1;
        private string email;
        private string cardNumber;
        private string pinCode;
        private int accountBalance;

        public BankAccount(Person p1, string email, string cardNumber, string pinCode, int accountBalance)
        {
            bool all = true;
            foreach(char a in cardNumber)
            {
                if (!Char.IsDigit(a))
                {
                    all = false;
                }
            }
            foreach (char a in pinCode)
            {
                if (!Char.IsDigit(a))
                {
                    all = false;
                }
            }
            all = cardNumber.Length == 9 && pinCode.Length == 4;
            if (all)
            {
                this.P1 = p1;
                this.Email = email;
                this.CardNumber = cardNumber;
                this.PinCode = pinCode;
                this.AccountBalance = accountBalance;
            }
          
        }

        public Person P1 { get => p1; set => p1 = value; }
        public string Email { get => email; set => email = value; }
        public string CardNumber { get => cardNumber; set => cardNumber = value; }
        public string PinCode { get => pinCode; set => pinCode = value; }
        public int AccountBalance { get => accountBalance; set => accountBalance = value; }
    }
}
